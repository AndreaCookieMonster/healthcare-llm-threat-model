# Contributing

- Open an issue for suggested changes.
- Submit PRs that update the spreadsheet in /data or edit Markdown directly.